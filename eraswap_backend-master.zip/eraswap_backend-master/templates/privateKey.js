module.exports=
`
Your Private Key is   <%= key %>
`;

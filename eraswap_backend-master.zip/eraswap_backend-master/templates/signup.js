module.exports=`
Please click this link to activate your account: <%= link %>
`
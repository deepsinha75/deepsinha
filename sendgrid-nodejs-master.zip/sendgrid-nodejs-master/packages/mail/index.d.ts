import MailService = require("@sendgrid/mail/src/mail");

export = MailService;
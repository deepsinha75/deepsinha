/**
 * Helper to convert an array of objects to JSON
 */
declare function arrayToJSON(arr: any[]): any[];

export = arrayToJSON;
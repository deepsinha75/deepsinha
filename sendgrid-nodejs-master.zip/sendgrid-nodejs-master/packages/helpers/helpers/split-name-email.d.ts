/**
 * Split name and email address from string
 */
declare function splitNameEmail(str: string): string[];

export = splitNameEmail;
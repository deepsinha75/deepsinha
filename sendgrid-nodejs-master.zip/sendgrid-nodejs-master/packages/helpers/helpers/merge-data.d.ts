/**
 * Merge data helper
 */
declare function mergeData<T, S>(base: T, data: S): T&S;

export = mergeData;
import Importer = require("@sendgrid/contact-importer/src/importer");

export = Importer;
import * as Parser from "./src/parser";

export = Parser;
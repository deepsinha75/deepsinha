import {RequestResponse} from "request";

export type ClientResponse = RequestResponse;
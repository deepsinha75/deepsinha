import {OptionsWithUrl} from "request";

export type ClientRequest = OptionsWithUrl;
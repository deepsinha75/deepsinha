# tokenManagerContract
Smart Contract to manage different tokens for a user

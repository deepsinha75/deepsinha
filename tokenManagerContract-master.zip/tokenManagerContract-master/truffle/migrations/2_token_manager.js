var TokenDirectory = artifacts.require("./TokenDirectory.sol");
var TokenManager = artifacts.require("./TokenManager.sol");

module.exports = function (deployer) {
    deployer.deploy(TokenDirectory).then(x => {
        console.log(x);
        deployer.deploy(TokenManager, x.address, x.address)
    });
};

# eraswap-frontend - Install and Run

1. Install Node.js and NPM
3. git clone https://github.com/BlockClusterApp/eraswap-frontend.git
4. cd eraswap-frontend && yarn install
5. yarn start

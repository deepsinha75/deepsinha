# Testing

```bash
yarn run lint                   # Find problematic patterns in code
yarn run check                  # Check source code for type errors
yarn run test                   # Run unit tests once
yarn run test-watch             # Run unit tests in watch mode
```

For more information visit http://facebook.github.io/jest/

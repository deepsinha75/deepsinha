// telegram token
var token = 'XXXXXXXXXXXXXXXXXXXXXX'
// firebase config
var config = {
    apiKey: "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
    authDomain: "XXXXXXXXXXX.firebaseapp.com",
    databaseURL: "https://XXXXXXXXX.firebaseio.com/",
    projectId: "XXXXXXXX",
    storageBucket: "XXXXXXXXXXXX.appspot.com",
};

exports.token = token;
exports.firebase_config = config;
